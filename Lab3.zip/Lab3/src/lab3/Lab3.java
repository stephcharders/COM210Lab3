/*
Author: Stephanie Harders
 */
package lab3;
import java.util.Stack;
import java.util.Scanner;

class bracketCheck {
  private String input;

  public bracketCheck(String in) {
    input = in;
  }

  public void check() {
    Stack<Character> Stack1 = new Stack<Character>();

    for (int j = 0; j < input.length(); j++) {
      char ch = input.charAt(j);
      switch (ch) {
      case '[': 
      case '{':
      case '(':
        Stack1.push(ch);
        break;
      case ']': 
      case '}':
      case ')':
        if (!Stack1.isEmpty()) {
          char chh = Stack1.pop();
          if ((ch == '}' && chh != '{') || (ch == ']' && chh != '[') || (ch == ')' && chh != '('))
            System.out.println("Error: " + ch + " at " + j);
        } else

          System.out.println("Error: " + ch + " at " + j);
        break;
      default:
        break;
      }
    }
    if (!Stack1.isEmpty()){
      System.out.println("Error: missing right delimiter");
    }
  }
}

public class Lab3 {
  public static void main(String[] args) {
    String input;
    Scanner myObj = new Scanner(System.in);  // Create a Scanner object
    System.out.println("Enter text that includes delimiters");
    String delimiter = myObj.nextLine();
    input = delimiter;

    bracketCheck Checking = new bracketCheck(input);
    Checking.check();
  }

}